import 'package:flutter/material.dart';
import '../models/worker.dart';

class WorkerCard extends StatelessWidget {
  final Worker worker;
  const WorkerCard({super.key, required this.worker});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: ListTile(
        leading: CircleAvatar(
          child: worker.avatarUrl != null
              ? null
              : Text(worker.name.isNotEmpty ? worker.name[0] : 'ف'),
          // For real avatar use CachedNetworkImageProvider(worker.avatarUrl)
        ),
        title: Text(worker.name,
            style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('${worker.profession} • ${worker.location}'),
        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.star, size: 16),
          Text(worker.rating.toString())
        ]),
        onTap: () {/* open worker detail / contact */},
      ),
    );
  }
}
