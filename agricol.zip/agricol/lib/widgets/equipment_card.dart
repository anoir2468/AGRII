import 'package:flutter/material.dart';
import '../models/equipment.dart';
import 'package:cached_network_image/cached_network_image.dart';

class EquipmentCard extends StatelessWidget {
  final Equipment equipment;
  const EquipmentCard({super.key, required this.equipment});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Colors.grey[200],
          child: equipment.imageUrl != null && equipment.imageUrl!.isNotEmpty
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: CachedNetworkImage(
                      imageUrl: equipment.imageUrl!,
                      width: 48,
                      height: 48,
                      fit: BoxFit.cover))
              : const Icon(Icons.agriculture),
        ),
        title: Text(equipment.title,
            style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(equipment.description,
            maxLines: 2, overflow: TextOverflow.ellipsis),
        trailing: Text('${equipment.price.toStringAsFixed(0)} DA',
            style: const TextStyle(fontWeight: FontWeight.w700)),
        onTap: () {/* open details */},
      ),
    );
  }
}
