import 'package:flutter/material.dart';

class FacilitiesScreen extends StatelessWidget {
  const FacilitiesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المنشآت')),
      body: const Center(child: Text('قوائم المنشآت الزراعية ستظهر هنا')),
    );
  }
}
