import 'package:flutter/material.dart';

class LandScreen extends StatelessWidget {
  const LandScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الأراضي')),
      body: const Center(child: Text('قوائم الأراضي المتاحة ستظهر هنا')),
    );
  }
}
