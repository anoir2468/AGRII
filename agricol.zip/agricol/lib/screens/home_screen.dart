import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'equipment_screen.dart';
import 'workers_screen.dart';
import 'training_screen.dart';
import 'land_screen.dart';
import 'facilities_screen.dart';
import 'supplies_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('منصة الفلاح الجزائري')),
      drawer: Drawer(
        child: ListView(
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(auth.user?.name ?? 'زائر'),
              accountEmail: Text(auth.user?.email ?? ''),
              currentAccountPicture: CircleAvatar(
                  child: Text((auth.user?.name ?? 'ز').substring(0, 1))),
            ),
            ListTile(
                leading: const Icon(Icons.agriculture),
                title: const Text('المعدات'),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const EquipmentScreen()))),
            ListTile(
                leading: const Icon(Icons.people),
                title: const Text('العمال'),
                onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const WorkersScreen()))),
            ListTile(
                leading: const Icon(Icons.school),
                title: const Text('التكوين'),
                onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const TrainingScreen()))),
            ListTile(
                leading: const Icon(Icons.landscape),
                title: const Text('الأراضي'),
                onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const LandScreen()))),
            ListTile(
                leading: const Icon(Icons.warehouse),
                title: const Text('المنشآت'),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => const FacilitiesScreen()))),
            ListTile(
                leading: const Icon(Icons.local_shipping),
                title: const Text('الإمدادات'),
                onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SuppliesScreen()))),
            const Divider(),
            ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('تسجيل الخروج'),
                onTap: () => auth.logout()),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Search & filters row
            Row(
              children: [
                Expanded(
                    child: TextField(
                  decoration: InputDecoration(
                      prefixIcon: const Icon(Icons.search),
                      hintText: 'ابحث عن معدات، عمال، دورات...',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8))),
                )),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.filter_list),
                    label: const Text('فلتر')),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
                child: GridView.count(
              crossAxisCount: 2,
              childAspectRatio: 1.05,
              children: [
                _homeCard(context, 'المعدات', Icons.agriculture),
                _homeCard(context, 'العمال', Icons.people),
                _homeCard(context, 'التكوين', Icons.school),
                _homeCard(context, 'الأراضي', Icons.landscape),
              ],
            )),
          ],
        ),
      ),
    );
  }

  Widget _homeCard(BuildContext context, String title, IconData icon) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      margin: const EdgeInsets.all(8),
      child: InkWell(
        onTap: () {
          switch (title) {
            case 'المعدات':
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const EquipmentScreen()));
              break;
            case 'العمال':
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const WorkersScreen()));
              break;
            case 'التكوين':
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const TrainingScreen()));
              break;
            case 'الأراضي':
              Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const LandScreen()));
              break;
          }
        },
        child: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 52),
          const SizedBox(height: 8),
          Text(title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600))
        ])),
      ),
    );
  }
}
