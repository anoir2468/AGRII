import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'package:image_picker/image_picker.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _phone = TextEditingController();
  final _password = TextEditingController();
  bool _loading = false;
  File? _avatar;

  Future<void> _pickAvatar() async {
    final p = ImagePicker();
    final f = await p.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (f != null)
      setState(() {
        _avatar = File(f.path);
      });
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context, listen: false);
    return Scaffold(
      appBar: AppBar(title: const Text('إنشاء حساب')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Center(
              child: InkWell(
                onTap: _pickAvatar,
                child: CircleAvatar(
                  radius: 44,
                  backgroundImage: _avatar != null ? FileImage(_avatar!) : null,
                  child: _avatar == null ? const Icon(Icons.camera_alt) : null,
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
                controller: _name,
                decoration: const InputDecoration(
                    labelText: 'الاسم الكامل', prefixIcon: Icon(Icons.person))),
            const SizedBox(height: 12),
            TextField(
                controller: _email,
                decoration: const InputDecoration(
                    labelText: 'البريد الإلكتروني',
                    prefixIcon: Icon(Icons.email))),
            const SizedBox(height: 12),
            TextField(
                controller: _phone,
                decoration: const InputDecoration(
                    labelText: 'الهاتف', prefixIcon: Icon(Icons.phone)),
                keyboardType: TextInputType.phone),
            const SizedBox(height: 12),
            TextField(
                controller: _password,
                decoration: const InputDecoration(
                    labelText: 'كلمة المرور', prefixIcon: Icon(Icons.lock)),
                obscureText: true),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _loading
                  ? null
                  : () async {
                      setState(() {
                        _loading = true;
                      });
                      try {
                        await auth.register(
                          name: _name.text.trim(),
                          email: _email.text.trim(),
                          password: _password.text,
                          phone: _phone.text.trim(),
                          avatarFile: _avatar,
                        );
                        if (mounted) Navigator.of(context).pop();
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text('فشل التسجيل: ${e.toString()}')));
                      } finally {
                        setState(() {
                          _loading = false;
                        });
                      }
                    },
              child: _loading
                  ? const CircularProgressIndicator()
                  : const Text('إنشاء الحساب'),
            ),
          ],
        ),
      ),
    );
  }
}
