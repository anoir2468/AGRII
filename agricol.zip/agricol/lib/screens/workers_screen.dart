import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/data_provider.dart';
import '../widgets/worker_card.dart';

class WorkersScreen extends StatelessWidget {
  const WorkersScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final data = Provider.of<DataProvider>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('العمال')),
      body: data.loadingWorkers
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: data.workers.length,
              itemBuilder: (ctx, i) => WorkerCard(worker: data.workers[i]),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {/* TODO: post new CV */},
        child: const Icon(Icons.add),
      ),
    );
  }
}
