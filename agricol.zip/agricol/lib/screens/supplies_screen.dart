import 'package:flutter/material.dart';

class SuppliesScreen extends StatelessWidget {
  const SuppliesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإمدادات')),
      body: const Center(child: Text('البذور والأسمدة والمبيدات ستظهر هنا')),
    );
  }
}
