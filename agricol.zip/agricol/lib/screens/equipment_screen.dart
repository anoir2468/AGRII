import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/data_provider.dart';
import '../widgets/equipment_card.dart';

class EquipmentScreen extends StatelessWidget {
  const EquipmentScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final data = Provider.of<DataProvider>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('المعدات')),
      body: data.loadingEquipment
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: data.equipment.length,
              itemBuilder: (ctx, i) =>
                  EquipmentCard(equipment: data.equipment[i]),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {/* TODO: add new equipment flow */},
        child: const Icon(Icons.add),
      ),
    );
  }
}
