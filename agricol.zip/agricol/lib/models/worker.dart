class Worker {
  final String id;
  final String name;
  final String profession;
  final String location;
  final double rating;
  final String? avatarUrl;
  final String bio;

  Worker({
    required this.id,
    required this.name,
    required this.profession,
    required this.location,
    this.rating = 0,
    this.avatarUrl,
    this.bio = '',
  });

  factory Worker.fromJson(Map<String, dynamic> j) => Worker(
        id: j['id'] ?? '',
        name: j['name'] ?? '',
        profession: j['profession'] ?? '',
        location: j['location'] ?? '',
        rating: (j['rating'] ?? 0).toDouble(),
        avatarUrl: j['avatarUrl'],
        bio: j['bio'] ?? '',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'profession': profession,
        'location': location,
        'rating': rating,
        'avatarUrl': avatarUrl,
        'bio': bio,
      };
}
