class Equipment {
  final String id;
  final String title;
  final String description;
  final double price;
  final String? imageUrl;
  final String ownerId;
  final bool forRent;

  Equipment({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    this.imageUrl,
    required this.ownerId,
    this.forRent = false,
  });

  factory Equipment.fromJson(Map<String, dynamic> j) => Equipment(
        id: j['id'] ?? '',
        title: j['title'] ?? '',
        description: j['description'] ?? '',
        price: (j['price'] ?? 0).toDouble(),
        imageUrl: j['imageUrl'],
        ownerId: j['ownerId'] ?? '',
        forRent: j['forRent'] ?? false,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'price': price,
        'imageUrl': imageUrl,
        'ownerId': ownerId,
        'forRent': forRent,
      };
}
