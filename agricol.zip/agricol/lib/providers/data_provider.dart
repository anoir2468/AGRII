import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/equipment.dart';
import '../models/worker.dart';

class DataProvider extends ChangeNotifier {
  final FirebaseFirestore _fire = FirebaseFirestore.instance;

  List<Equipment> _equipment = [];
  List<Worker> _workers = [];

  bool loadingEquipment = false;
  bool loadingWorkers = false;

  List<Equipment> get equipment => _equipment;
  List<Worker> get workers => _workers;

  DataProvider() {
    // load initial mock then subscribe to firestore
    _subscribeEquipment();
    _subscribeWorkers();
  }

  void _subscribeEquipment() {
    loadingEquipment = true;
    notifyListeners();
    _fire.collection('equipment').snapshots().listen((snap) {
      _equipment = snap.docs
          .map((d) => Equipment.fromJson({...d.data(), 'id': d.id}))
          .toList();
      loadingEquipment = false;
      notifyListeners();
    }, onError: (e) {
      loadingEquipment = false;
      notifyListeners();
    });
  }

  void _subscribeWorkers() {
    loadingWorkers = true;
    notifyListeners();
    _fire.collection('workers').snapshots().listen((snap) {
      _workers = snap.docs
          .map((d) => Worker.fromJson({...d.data(), 'id': d.id}))
          .toList();
      loadingWorkers = false;
      notifyListeners();
    }, onError: (_) {
      loadingWorkers = false;
      notifyListeners();
    });
  }

  Future<void> addEquipment(Equipment item) async {
    await _fire.collection('equipment').add(item.toJson());
  }

  Future<void> addWorker(Worker w) async {
    await _fire.collection('workers').add(w.toJson());
  }
}
