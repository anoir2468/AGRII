import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb;
import '../models/user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

class AuthProvider extends ChangeNotifier {
  AppUser? _user;
  bool get isAuthenticated => _user != null;
  AppUser? get user => _user;

  final fb.FirebaseAuth _auth = fb.FirebaseAuth.instance;
  final FirebaseFirestore _fire = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;

  // load from firebase user if logged in
  AuthProvider() {
    _auth.authStateChanges().listen((fb.User? u) async {
      if (u != null) {
        final doc = await _fire.collection('users').doc(u.uid).get();
        if (doc.exists) {
          _user = AppUser.fromJson({'id': u.uid, ...doc.data()!});
        } else {
          _user = AppUser(
              id: u.uid,
              name: u.displayName ?? 'مستخدم',
              email: u.email ?? '',
              phone: u.phoneNumber ?? '');
        }
      } else {
        _user = null;
      }
      notifyListeners();
    });
  }

  // Email/password registration + firestore record
  Future<void> register({
    required String name,
    required String email,
    required String password,
    required String phone,
    File? avatarFile,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
        email: email, password: password);
    final uid = cred.user!.uid;
    String? avatarUrl;
    if (avatarFile != null) {
      final ref = _storage.ref('avatars/$uid.jpg');
      await ref.putFile(avatarFile);
      avatarUrl = await ref.getDownloadURL();
    }
    final user = AppUser(
        id: uid, name: name, email: email, phone: phone, avatarUrl: avatarUrl);
    await _fire.collection('users').doc(uid).set(user.toJson());
    _user = user;
    notifyListeners();
  }

  // Login with email/password
  Future<void> login({required String email, required String password}) async {
    final cred = await _auth.signInWithEmailAndPassword(
        email: email, password: password);
    final uid = cred.user!.uid;
    final doc = await _fire.collection('users').doc(uid).get();
    if (doc.exists) {
      _user = AppUser.fromJson({'id': uid, ...doc.data()!});
    } else {
      _user = AppUser(
          id: uid,
          name: cred.user!.displayName ?? 'مستخدم',
          email: email,
          phone: cred.user!.phoneNumber ?? '');
    }
    notifyListeners();
  }

  Future<void> logout() async {
    await _auth.signOut();
    _user = null;
    notifyListeners();
  }

  // Update profile
  Future<void> updateProfile(
      {String? name, String? phone, File? avatar}) async {
    if (_user == null) return;
    final uid = _user!.id;
    String? avatarUrl = _user!.avatarUrl;
    if (avatar != null) {
      final ref = _storage.ref('avatars/$uid.jpg');
      await ref.putFile(avatar);
      avatarUrl = await ref.getDownloadURL();
    }
    final updated = AppUser(
        id: uid,
        name: name ?? _user!.name,
        email: _user!.email,
        phone: phone ?? _user!.phone,
        avatarUrl: avatarUrl);
    await _fire.collection('users').doc(uid).update(updated.toJson());
    _user = updated;
    notifyListeners();
  }
}
