# منصة الفلاح الجزائري - تطبيق موبايل

مشروع Flutter جاهز مع بنية منظمة، دعم RTL وواجهة عربية.  
**ملاحظات مهمة:** يجب إضافة ملفات إعدادات Firebase (google-services.json و GoogleService-Info.plist) لتشغيل خدمات Firebase الحقيقية.

تشغيل:
```bash
flutter pub get
flutter run
```
